"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import {
  BarChart3,
  Box,
  DollarSign,
  Download,
  Home,
  LayoutDashboard,
  LogOut,
  Package,
  Plus,
  Search,
  Settings,
  ShoppingCart,
  Truck,
  Users,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function AdminDashboard() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  // Dados simulados para o dashboard
  const dashboardData = {
    revenue: {
      total: 12450.75,
      percentage: 12.5,
      isUp: true,
    },
    orders: {
      total: 156,
      percentage: 8.2,
      isUp: true,
    },
    customers: {
      total: 89,
      percentage: 5.1,
      isUp: true,
    },
    products: {
      total: 32,
      percentage: 2.3,
      isUp: false,
    },
    recentOrders: [
      {
        id: "12345",
        customer: "Carlos Silva",
        date: "15/04/2025",
        status: "Entregue",
        total: 349.7,
      },
      {
        id: "12346",
        customer: "Maria Oliveira",
        date: "14/04/2025",
        status: "Em processamento",
        total: 129.9,
      },
      {
        id: "12347",
        customer: "João Santos",
        date: "13/04/2025",
        status: "Em trânsito",
        total: 89.9,
      },
      {
        id: "12348",
        customer: "Ana Pereira",
        date: "12/04/2025",
        status: "Entregue",
        total: 199.5,
      },
      {
        id: "12349",
        customer: "Pedro Costa",
        date: "11/04/2025",
        status: "Cancelado",
        total: 259.8,
      },
    ],
    products: [
      {
        id: "1",
        name: "Torneira Monocomando",
        price: 129.9,
        stock: 45,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: "2",
        name: "Torneira Bica Alta",
        price: 159.9,
        stock: 32,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: "3",
        name: "Torneira para Banheiro",
        price: 89.9,
        stock: 18,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: "4",
        name: "Torneira Elétrica",
        price: 199.9,
        stock: 27,
        image: "/placeholder.svg?height=50&width=50",
      },
      {
        id: "5",
        name: "Kit Torneira e Ducha",
        price: 249.9,
        stock: 12,
        image: "/placeholder.svg?height=50&width=50",
      },
    ],
    customers: [
      {
        id: "1",
        name: "Carlos Silva",
        email: "carlos@example.com",
        orders: 8,
        spent: 1245.6,
        lastOrder: "15/04/2025",
      },
      {
        id: "2",
        name: "Maria Oliveira",
        email: "maria@example.com",
        orders: 5,
        spent: 789.3,
        lastOrder: "14/04/2025",
      },
      {
        id: "3",
        name: "João Santos",
        email: "joao@example.com",
        orders: 3,
        spent: 459.7,
        lastOrder: "10/04/2025",
      },
      {
        id: "4",
        name: "Ana Pereira",
        email: "ana@example.com",
        orders: 2,
        spent: 299.8,
        lastOrder: "05/04/2025",
      },
      {
        id: "5",
        name: "Pedro Costa",
        email: "pedro@example.com",
        orders: 1,
        spent: 259.8,
        lastOrder: "01/04/2025",
      },
    ],
  }

  const handleLogout = () => {
    // Simulação de logout
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso",
    })
    router.push("/")
  }

  return (
    <div className="grid min-h-screen w-full lg:grid-cols-[280px_1fr]">
      <div className="hidden border-r bg-muted/40 lg:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-[60px] items-center border-b px-6">
            <Link href="/admin" className="flex items-center gap-2 font-bold text-xl text-primary">
              <span>Painel Admin</span>
            </Link>
          </div>
          <div className="flex-1 overflow-auto py-2">
            <nav className="grid items-start px-4 text-sm font-medium">
              <Link
                href="/admin"
                className="flex items-center gap-3 rounded-lg bg-muted px-3 py-2 text-primary transition-all"
              >
                <LayoutDashboard className="h-4 w-4" />
                Dashboard
              </Link>
              <Link
                href="/admin/products"
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
              >
                <Package className="h-4 w-4" />
                Produtos
              </Link>
              <Link
                href="/admin/orders"
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
              >
                <ShoppingCart className="h-4 w-4" />
                Pedidos
              </Link>
              <Link
                href="/admin/customers"
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
              >
                <Users className="h-4 w-4" />
                Clientes
              </Link>
              <Link
                href="/admin/analytics"
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
              >
                <BarChart3 className="h-4 w-4" />
                Análises
              </Link>
              <Link
                href="/admin/settings"
                className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
              >
                <Settings className="h-4 w-4" />
                Configurações
              </Link>
            </nav>
          </div>
          <div className="mt-auto p-4">
            <Button variant="outline" className="w-full justify-start" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Sair
            </Button>
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-6 lg:h-[60px]">
          <Link href="/" className="lg:hidden">
            <Package className="h-6 w-6" />
            <span className="sr-only">Home</span>
          </Link>
          <div className="w-full flex-1">
            <form>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Pesquisar..."
                  className="w-full appearance-none bg-background pl-8 shadow-none md:w-2/3 lg:w-1/3"
                />
              </div>
            </form>
          </div>
          <Link href="/" className="flex items-center gap-2 text-sm font-medium">
            <Home className="h-4 w-4" />
            Ir para a loja
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Image src="/placeholder-user.jpg" width="32" height="32" className="rounded-full" alt="Avatar" />
                <span className="sr-only">Toggle user menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Configurações</DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout}>Sair</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>
        <main className="flex-1 overflow-auto p-6">
          <Tabs defaultValue="overview">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <TabsList>
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="analytics">Análises</TabsTrigger>
                <TabsTrigger value="reports">Relatórios</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">R$ {dashboardData.revenue.total.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground flex items-center">
                      <span className={`mr-1 ${dashboardData.revenue.isUp ? "text-green-500" : "text-red-500"}`}>
                        {dashboardData.revenue.isUp ? "↑" : "↓"} {dashboardData.revenue.percentage}%
                      </span>
                      em relação ao mês anterior
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Pedidos</CardTitle>
                    <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dashboardData.orders.total}</div>
                    <p className="text-xs text-muted-foreground flex items-center">
                      <span className={`mr-1 ${dashboardData.orders.isUp ? "text-green-500" : "text-red-500"}`}>
                        {dashboardData.orders.isUp ? "↑" : "↓"} {dashboardData.orders.percentage}%
                      </span>
                      em relação ao mês anterior
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Clientes</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dashboardData.customers.total}</div>
                    <p className="text-xs text-muted-foreground flex items-center">
                      <span className={`mr-1 ${dashboardData.customers.isUp ? "text-green-500" : "text-red-500"}`}>
                        {dashboardData.customers.isUp ? "↑" : "↓"} {dashboardData.customers.percentage}%
                      </span>
                      em relação ao mês anterior
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Produtos</CardTitle>
                    <Box className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dashboardData.products.length}</div>
                    <p className="text-xs text-muted-foreground flex items-center">
                      <span className={`mr-1 ${dashboardData.products.isUp ? "text-green-500" : "text-red-500"}`}>
                        {dashboardData.products.isUp ? "↑" : "↓"} {dashboardData.products.percentage}%
                      </span>
                      em relação ao mês anterior
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                <Card className="lg:col-span-4">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Pedidos Recentes</CardTitle>
                      <CardDescription>Últimos 5 pedidos realizados</CardDescription>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Exportar
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Pedido</TableHead>
                          <TableHead>Cliente</TableHead>
                          <TableHead>Data</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dashboardData.recentOrders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">#{order.id}</TableCell>
                            <TableCell>{order.customer}</TableCell>
                            <TableCell>{order.date}</TableCell>
                            <TableCell>
                              <div
                                className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${
                                  order.status === "Entregue"
                                    ? "bg-green-100 text-green-800"
                                    : order.status === "Cancelado"
                                      ? "bg-red-100 text-red-800"
                                      : "bg-blue-100 text-blue-800"
                                }`}
                              >
                                {order.status}
                              </div>
                            </TableCell>
                            <TableCell className="text-right">R$ {order.total.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      Ver Todos os Pedidos
                    </Button>
                  </CardFooter>
                </Card>
                <Card className="lg:col-span-3">
                  <CardHeader>
                    <CardTitle>Produtos em Estoque Baixo</CardTitle>
                    <CardDescription>Produtos com menos de 20 unidades</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {dashboardData.products
                        .filter((product) => product.stock < 20)
                        .map((product) => (
                          <div key={product.id} className="flex items-center gap-4">
                            <div className="relative h-10 w-10 overflow-hidden rounded">
                              <Image
                                src={product.image || "/placeholder.svg"}
                                alt={product.name}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div className="flex-1 space-y-1">
                              <p className="text-sm font-medium leading-none">{product.name}</p>
                              <p className="text-sm text-muted-foreground">R$ {product.price.toFixed(2)}</p>
                            </div>
                            <div className="text-sm font-medium">
                              {product.stock < 10 ? (
                                <span className="text-red-500">{product.stock} un.</span>
                              ) : (
                                <span className="text-yellow-500">{product.stock} un.</span>
                              )}
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      Gerenciar Estoque
                    </Button>
                  </CardFooter>
                </Card>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Produtos Mais Vendidos</CardTitle>
                    <CardDescription>Top 5 produtos mais vendidos este mês</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produto</TableHead>
                          <TableHead>Preço</TableHead>
                          <TableHead>Vendas</TableHead>
                          <TableHead className="text-right">Receita</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">Torneira Monocomando</TableCell>
                          <TableCell>R$ 129,90</TableCell>
                          <TableCell>42</TableCell>
                          <TableCell className="text-right">R$ 5.455,80</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Torneira Bica Alta</TableCell>
                          <TableCell>R$ 159,90</TableCell>
                          <TableCell>38</TableCell>
                          <TableCell className="text-right">R$ 6.076,20</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Kit Torneira e Ducha</TableCell>
                          <TableCell>R$ 249,90</TableCell>
                          <TableCell>25</TableCell>
                          <TableCell className="text-right">R$ 6.247,50</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Torneira Elétrica</TableCell>
                          <TableCell>R$ 199,90</TableCell>
                          <TableCell>18</TableCell>
                          <TableCell className="text-right">R$ 3.598,20</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">Torneira para Banheiro</TableCell>
                          <TableCell>R$ 89,90</TableCell>
                          <TableCell>15</TableCell>
                          <TableCell className="text-right">R$ 1.348,50</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Ações Rápidas</CardTitle>
                    <CardDescription>Acesso rápido às principais funções</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button className="w-full justify-start" size="lg">
                      <Plus className="mr-2 h-4 w-4" />
                      Adicionar Produto
                    </Button>
                    <Button className="w-full justify-start" variant="outline" size="lg">
                      <Truck className="mr-2 h-4 w-4" />
                      Atualizar Status de Pedido
                    </Button>
                    <Button className="w-full justify-start" variant="outline" size="lg">
                      <BarChart3 className="mr-2 h-4 w-4" />
                      Gerar Relatório
                    </Button>
                    <Button className="w-full justify-start" variant="outline" size="lg">
                      <Settings className="mr-2 h-4 w-4" />
                      Configurações da Loja
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Análises Detalhadas</CardTitle>
                  <CardDescription>Visualize métricas detalhadas da sua loja</CardDescription>
                </CardHeader>
                <CardContent className="h-[400px] flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">Gráficos de Análise</h3>
                    <p className="text-muted-foreground mt-1">
                      Aqui seriam exibidos gráficos detalhados de vendas, tráfego e conversão.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reports" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Relatórios</CardTitle>
                  <CardDescription>Gere e baixe relatórios da sua loja</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium">Relatório de Vendas</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Resumo detalhado de todas as vendas no período selecionado.
                      </p>
                      <Button variant="outline" size="sm" className="mt-2">
                        <Download className="mr-2 h-4 w-4" />
                        Exportar
                      </Button>
                    </div>
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium">Relatório de Estoque</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Situação atual do estoque e histórico de movimentações.
                      </p>
                      <Button variant="outline" size="sm" className="mt-2">
                        <Download className="mr-2 h-4 w-4" />
                        Exportar
                      </Button>
                    </div>
                    <div className="border rounded-lg p-4">
                      <h3 className="font-medium">Relatório de Clientes</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Análise de clientes, frequência de compras e valor médio.
                      </p>
                      <Button variant="outline" size="sm" className="mt-2">
                        <Download className="mr-2 h-4 w-4" />
                        Exportar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
